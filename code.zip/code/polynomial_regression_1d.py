import assignment1 as a1
import numpy as np
import matplotlib.pyplot as plt

# dataset intialization
(countries, features, values) = a1.load_unicef_data()

targets = values[:,1]
x = values[:,7:15]
# x = a1.normalize_data(x)

N_TRAIN = 100;
x_train = x[0:N_TRAIN,:]
x_test = x[N_TRAIN:,:]
t_train = targets[0:N_TRAIN]
t_test = targets[N_TRAIN:]

train_err = {}
test_err = {}

for i in range(0, 8):
    (w, tr_err) = a1.linear_regression(x_train[:,i], t_train, 'polynomial', 0, 3)
    (t_est, te_err) = a1.evaluate_regression(x_test[:,i], t_test, w, 'polynomial', 3)
    train_err[i] = np.array(tr_err)[0][0]
    test_err[i] = np.array(te_err)[0][0]


# Produce a plot of results.
x_label = np.arange(8,16)

plt.bar(x_label - 0.2, train_err.values(), width = 0.4, label = "train error")
plt.bar(x_label + 0.2, test_err.values(), width = 0.4, label = "test error")

plt.xlabel("feature")
plt.ylabel("RMS")
plt.legend(loc="upper left")
plt.title('Fit with degree 3 polynomial, no regularization')

plt.show()

