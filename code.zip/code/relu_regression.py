import assignment1 as a1
import numpy as np
import matplotlib.pyplot as plt

(countries, features, values) = a1.load_unicef_data()

targets = values[:,1]
x = values[:,7:]
#x = a1.normalize_data(x)

N_TRAIN = 100;
# Select a single feature.
x_train = x[0:N_TRAIN,3]
t_train = targets[0:N_TRAIN]
x_test = x[N_TRAIN:,3]
t_test = targets[N_TRAIN:]

# Implement ReLU regression
(w, tr_err) = a1.linear_regression(x_train, t_train, 'ReLU', 0, 0)
(t_est, te_err) = a1.evaluate_regression(x_test, t_test, w, 'ReLU', 0)

# Print the training error and testing error
print(tr_err)
print(te_err)


# Use linspace to get a set of samples on which to evaluate
x_ev = np.linspace(np.asscalar(min(x_train)), np.asscalar(max(x_train)), num=500)

phi = np.vstack((np.ones((1,len(x_ev))), np.maximum(0, -x_ev + 5000)))

# Compute each y_ev with the above phi and w
y_ev = phi.T * w

# Plot the regression estimate and training points
plt.plot(x_ev,y_ev,'r.-')
plt.plot(x_train,t_train,'bo')
plt.plot(x_test,t_test,'go')


plt.title('A visualization of a regression estimate using random outputs')
plt.show()


