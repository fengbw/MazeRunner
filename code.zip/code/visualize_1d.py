#!/usr/bin/env python

import assignment1 as a1
import numpy as np
import matplotlib.pyplot as plt


(countries, features, values) = a1.load_unicef_data()

targets = values[:,1]
x = values[:,7:]
#x = a1.normalize_data(x)

N_TRAIN = 100;
# Select a single feature.
x_train = x[0:N_TRAIN,5]
t_train = targets[0:N_TRAIN]
x_test = x[N_TRAIN:,5]
t_test = targets[N_TRAIN:]

# Set the degree of polynomial
degree = 3

# Plot a curve showing learned function.
# Use linspace to get a set of samples on which to evaluate
x_ev = np.linspace(np.asscalar(min(x_train)), np.asscalar(max(x_train)), num = 500)

# TO DO:: Put your regression estimate here in place of x_ev.
# Evaluate regression on the linspace samples.
# y_ev, _  = a1.evaluate_regression()

# Learn the weight w for feature 10 from training data
(w, tr_err) = a1.linear_regression(x_train, t_train, 'polynomial', 0, degree)

# Compute the phi(x_ev)
phi = np.ones((1,len(x_ev)))
for i in range(1, degree + 1):
    phi = np.vstack((phi, np.power(x_ev, i)))

# Compute each y_ev with the above phi and w
y_ev = phi.T * w

# Plot the regression estimate and training points
plt.plot(x_ev,y_ev,'r.-')
plt.plot(x_train,t_train,'bo')
plt.plot(x_test,t_test,'go')
#plt.legend(loc="upper left")


plt.title('A visualization of a regression estimate using random outputs')
plt.show()