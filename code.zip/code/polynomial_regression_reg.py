import assignment1 as a1
import numpy as np
import matplotlib.pyplot as plt

# Data initialization
(countries, features, values) = a1.load_unicef_data()

targets = values[:,1]
x = values[:,7:]
x = a1.normalize_data(x)

N_TRAIN = 100
x_train = x[0:N_TRAIN,:]
x_test = x[N_TRAIN:,:]
t_train = targets[0:N_TRAIN]
t_test = targets[N_TRAIN:]

# Cross validation
#x_validate
#t_validate

# Set up the degree of polynomial
degree = 2

# Set up the range for reg_lamda
lamda_range = [0, 10 ** -2, 10 ** -1, 10 ** 0, 10 ** 1, 10 ** 2, 10 ** 3, 10 ** 4]


# _whole matrix is used to store the all the computed training error and validation error
# validation_err_whole[i][j] denotes the validation error
# when using the ith validation set and jth lamda
train_err_whole = np.zeros((10,len(lamda_range)))
validation_err_whole = np.zeros((10,len(lamda_range)))


# Implement regression
for i in range(0, 10):
    for j in range(0, len(lamda_range)):
        # Split the training set for training and validation
        i_row = i * 10
        x_train_new = np.delete(x_train, [i_row,i_row + 10], axis=0)
        t_train_new = np.delete(t_train, [i_row,i_row + 10], axis=0)
        x_validation = x_train[i_row:i_row + 10,:]
        t_validation = t_train[i_row:i_row + 10,:]

        (w, tr_err) = a1.linear_regression(x_train_new, t_train_new, 'polynomial', lamda_range[j], degree)
        (t_est, te_err) = a1.evaluate_regression(x_validation, t_validation, w, 'polynomial', degree)
        train_err_whole[i][j] = np.array(tr_err)[0][0]
        validation_err_whole[i][j] = np.array(te_err)[0][0]

# Compute the average error on every validation set
validation_error = np.mean(validation_err_whole, axis = 0)

print(validation_error)

# Produce a plot of results.
plt.semilogx(lamda_range,validation_error)
#plt.plot(range(0, len(test_err_whole[0])), test_err_whole[0])


plt.ylabel('RMS')
plt.legend(['validation error'])
plt.title('Fit with polynomials, with regularization')
plt.xlabel('reg_lamda')
plt.show()